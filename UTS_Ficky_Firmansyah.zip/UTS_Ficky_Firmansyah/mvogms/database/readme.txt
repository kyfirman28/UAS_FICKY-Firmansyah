

---------------------------------------------------
Admin Access
email: admin
password: admin123
----------------------------------------------------
Sample User Access
email: ahmad123@gmail.com
password: 123456789
----------------------------------------------------
Sample Vendor Access
email/user : alanwar123
password   : 123456789


